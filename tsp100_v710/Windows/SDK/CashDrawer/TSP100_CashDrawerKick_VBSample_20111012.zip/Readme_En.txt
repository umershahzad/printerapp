_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
TSP100 Sample Program of Cash Drawer Kicker for Visual Basic 6.0

                                                                10/12/2011

_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

================
  Introduction
================
This component allows for direct control of any Cash Drawer devices that
are connected to the TSP100. Specifically, this control has been designed
so that Cash Drawers can be opened without needing to print anything.


==============
  Properties
==============
PrinterQueueName (String)

    This property holds the printer queue name (as established in the
    Windows Printer's & Faxes folder) associated with the device being
    controlled.


CashDrawerCircuit (CashDrawerCircuit)

    This property controls which Cash Drawer is opened during subsequent
    calls to the OpenDrawer method. Possible values are:

    Public Enum CashDrawerCircuit
        PrimaryCircuit
        SecondaryCircuit
    End Enum


EnergizingPulseWidth (Integer)

    Retreives or sets the width (in milliseconds) of the energizing pulse
    that the printer will send to the Cash Drawer when opening it during
    subsequent calls to the OpenDrawer method. This property is made
    available to accommodate the many different types of Cash Drawers
    available on the market, some of which require only a short engergizing
    pulse and others which require longer energizing pulses. This parameter
    can be set to any Integer value between 10 and 1270 (meaning 10
    milliseconds and 1270 milliseconds respectively). This property is only
    applicable to the primary Cash Drawer.


DelayPulseWidth (Integer)

    Retreives or sets the width (in milliseconds) of the delay pulse that
    the printer will wait for after opening the Cash Drawer during
    subsequent calls to the OpenDrawer method. This parameter can be set to
    any Integer value between 10 and 1270 (meaning 10 milliseconds and 1270
    milliseconds respectively). This property is only applicable to the
    primary Cash Drawer.


IsPrimaryCashDrawerSignalling (Boolean)
(Read Only)(Error on Failure)

    Retreives the current (real-time) status of the Primary Cash Drawer.
    Specifically, it returns true if the Primary Cash Drawer is outputting
    a voltage level to the printer and false if no voltage level is being
    outputted. Typically cash drawers output voltage to the printer when
    they are opened, but some cash drawers have negatively-wired detection
    switches, and so this method simply indicates the status of the
    drawer's outputted voltage; this status must be paired with knowledge
    of the specific Cash Drawer being used to determine if the drawer is
    opened or closed. The potential errors of this property are as follows:

        1 + (vbObjectError + 512) - indicating that the PrinterQueueName
        property is not associated with a valid TSP100 device

        2 + (vbObjectError + 512) - indicating that a communications error
        occurred while trying to control the TSP100 device


=============
  Functions
=============
OpenDrawer() (Error on Failure)

    Opens the Cash Drawer in the manner specified in the properties of
    the control. The potential errors of this function are as follows:

        1 + (vbObjectError + 512) - indicating that the PrinterQueueName
        property does is not associated with a valid TSP100 device

        2 + (vbObjectError + 512) - indicating that a communications error
        occurred while trying to control the TSP100 device


WaitForPrimaryCashDrawerSignalLevel(SignalLevel As Boolean,
TimeoutMilliseconds As Long) (Error on Failure)

    Polls the Primary Cash Drawer's status until it begins signaling at the
    specified signal level or will timeout after the specified timeout
    period (1 second = 1 * 1000 milliseconds). The potential errors of this
    function are as follows:

        1 + (vbObjectError + 512) - indicating that the PrinterQueueName
        property does is not associated with a valid TSP100 device

        2 + (vbObjectError + 512) - indicating that a communications error
        occurred while trying to control the TSP100 device

        3 + (vbObjectError + 512) - indicating that the control timed-out
        before the Cash Drawer attained the specified signal level


=============
  Copyright
=============
 (C)Star Micronics Co., Ltd. All rights reserved.
