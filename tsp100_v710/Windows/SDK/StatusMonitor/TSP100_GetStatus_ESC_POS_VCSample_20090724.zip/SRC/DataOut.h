// DataOut.h: CDataOut �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATAOUT_H__8C04E2C1_C040_11D8_9E06_00010339F59B__INCLUDED_)
#define AFX_DATAOUT_H__8C04E2C1_C040_11D8_9E06_00010339F59B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataOut  
{
public:
	BOOL CheckPort();
	BOOL TransmissionData(unsigned char *lpBuffer, unsigned long lLength);
	CDataOut();
	virtual ~CDataOut();

};

#endif // !defined(AFX_DATAOUT_H__8C04E2C1_C040_11D8_9E06_00010339F59B__INCLUDED_)
