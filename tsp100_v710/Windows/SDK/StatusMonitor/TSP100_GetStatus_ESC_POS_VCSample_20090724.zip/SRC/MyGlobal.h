extern	int					iPort;					// Interface	Port
extern	int					iBaudRate;				//				Baud Rate
extern	int					iDataBit;				//				Data Bit
extern	int					iParity;				//				Parity Bit
extern	int					iStopBit;				//				Stop Bit
extern	int					iProtocol;				// 0 = Xon/Xoff  1 = CTR  2 = DSR  3 = CTR&DSR  4 = All Disable

extern	unsigned char		sData[];				// Transmission data save area
extern	long				lDataLength;			// Transmission data length
extern	char				sBuffer[];				// for ASCII Dialog
extern	long				lBufLength;				// for ASCII Dialog

//extern	int					iNumber;				// Hex Character -> Number

extern	CString				strDisplay;				// for Status
extern	int					iPortCheck;				// for Status

typedef struct CommunicationInfoTag
{
	BOOL bParallel;									// Serial or Parallel
	long nPort;										// COM or LPT
	long nBaud;										// Baud Rate
	long nData;										// Data Bit
	long nParity;									// Parity Check
	long nStop;										// Stop Bit
}COMMUNICATIONINFO;

extern COMMUNICATIONINFO	Communication;
extern DWORD                dwPlatformId;
extern HANDLE				hCommPort;
