#include "stdafx.h"
#include "MyGlobal.h"

int					iPort;					// Interface	Port
int					iBaudRate;				//				Baud Rate
int					iDataBit;				//				Data Bit
int					iParity;				//				Parity Bit
int					iStopBit;				//				Stop Bit
int					iProtocol;				// 0 = Xon/Xoff  1 = CTR  2 = DSR  3 = CTR&DSR  4 = All Disable

unsigned char		sData[2500000];			// Transmission data save area
long				lDataLength;			// Transmission data length
char				sBuffer[1024];			// for ASCII Dialog
long				lBufLength;				// for ASCII Dialog

CString				strDisplay;				// for Status
int					iPortCheck;				// for Status

COMMUNICATIONINFO	Communication;
DWORD				dwPlatformId;
HANDLE				hCommPort;
