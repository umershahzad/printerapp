// PortOpen.h: CPortOpen �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PORTOPEN_H__8C04E2C0_C040_11D8_9E06_00010339F59B__INCLUDED_)
#define AFX_PORTOPEN_H__8C04E2C0_C040_11D8_9E06_00010339F59B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPortOpen  
{
public:
	BOOL SelectPort();
	CPortOpen();
	virtual ~CPortOpen();

};

#endif // !defined(AFX_PORTOPEN_H__8C04E2C0_C040_11D8_9E06_00010339F59B__INCLUDED_)
