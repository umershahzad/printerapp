// StatusRead.h: CStatusRead �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STATUSREAD_H__06C6DE80_C115_11D8_9E06_00010339F59B__INCLUDED_)
#define AFX_STATUSREAD_H__06C6DE80_C115_11D8_9E06_00010339F59B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CStatusRead  
{
public:
	BOOL GetStatus();
	CStatusRead();
	virtual ~CStatusRead();

};

#endif // !defined(AFX_STATUSREAD_H__06C6DE80_C115_11D8_9E06_00010339F59B__INCLUDED_)
