// StatusRead.cpp: CStatusRead �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GetStatus.h"
#include "StatusRead.h"
#include "MyGlobal.h"

#include <WINIOCTL.H>
//#include "NTDDPAR.H"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

CStatusRead::CStatusRead()
{

}

CStatusRead::~CStatusRead()
{

}

BOOL CStatusRead::GetStatus()
{
	int				iErrorCheck;
	unsigned char	sReadData[128+8];
	DWORD			dwReadByte = 0, dwCounter = 0;
	CString			strPlus;
	CString			strHex = " Hex ";

	strDisplay = "";

	iErrorCheck = ReadFile(hCommPort, &sReadData, 128, &dwReadByte, NULL);

	if((dwReadByte == 0) | (iErrorCheck == 0))
	{
		return	FALSE;
	}
	else
	{
		for( dwCounter = 0; dwCounter < dwReadByte; dwCounter++ )
		{
			strPlus.Format(" %02x", sReadData[dwCounter]);
			strDisplay += strPlus;
			strDisplay += strHex;
		}
	}

	return	TRUE;
}
