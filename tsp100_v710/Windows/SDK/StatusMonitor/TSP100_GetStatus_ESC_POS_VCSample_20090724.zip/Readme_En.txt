_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
TSP100 Sample Program of Get Printer Status for Visual C++ 6.0
    For ESC/POS Mode
                                                                07/24/2009

_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

===========
  Purpose
===========
This sample program provides you to get the printer status of Star TSP100
POS Printer.

This sample program offers you its source file, so that you can use it as
you like for your software development.

To get the printer status, please use the <DLE EOT n> command.
n=1, Printer Status
n=2, Off Line Status
n=3, Error Status
n=4, Paper End Status
n=5, Presenter Paper Status


==============
  How to use
==============
1. Port Selection
   Selecting the port from COM1 - 22.

2. Port Configuration
   Setting the COM port from the pull-down menu.

3. Selecting the command to get the printer status
   Selecting the commands which you need from the pull-down menu.

4. Getting the printer status
   Clicking 'Get Status' button and you can get the printer status now.

5. Finishing the program
   Clicking the 'Exit' button to finish the program.


=============
  Copyright
=============
Copyright (C) 2009 Star Micronics Co., Ltd. All rights reserved.
