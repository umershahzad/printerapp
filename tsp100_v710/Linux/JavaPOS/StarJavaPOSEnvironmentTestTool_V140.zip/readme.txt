////////////////////////////////////////////////////////////////////////

 - StarJavaPOSEnvironmentTestTool Ver1.4.0 -
       Readme File                                            06/27/2016
       
   Copyright (C) 2016 Star Micronics Co., Ltd. All rights reserved.     
////////////////////////////////////////////////////////////////////////

*This ReadMe File applies to StarJavaPOSEnvironmentTestTool

  Thank you very much for purchasing Star Printer.

  Contents:

    1.  About "StarJavaPOSEnvironmentTestTool"
    2.  Package Contents 
    3.  Java Virtual Machine Requirement
    4.  Supported Star POS Printer Model
    5.  Supported Interface
    6.  How to Install
    7.  How to Use
    8.  Software Evaluation Environment
    9.  Release Notes


=========================================
1. About "StarJavaPOSEnvironmentTestTool"
=========================================

This software is the tool which is confirming 
whether installation of StarJavaPOSDriver is completed normally.

If can not work the StarJavaPOS Driver after installing on PC, please use this tool.

Please refer to "7. How to Use" to understand the usage.

*Please perform settings to use this tool by all means.
  Please refer to "6. How to Install" to understand the settings method.


====================
2. Java Package Contents 
====================
    . Linux_x86
      . Software
      . IOPortConnection_Install_x32
      . CheckStart.sh
      . IOConnectionCheck.sh
      . StarJavaPOSCheck.sh
      . CheckResultSample
    . Linux_x64
      . Software
      . IOPortConnection_Install_x64
      . CheckStart.sh
      . IOConnectionCheck.sh
      . StarJavaPOSCheck.sh
      . CheckResultSample
    . SoftwareLicenseAgreement.pdf
    . SoftwareLicenseAgreementAppendix.pdf
    . readme.txt


===================================
3. Java Virtual Machine Requirement
===================================
    Java2 Standard Edition 1.4.2 or higher

    NOTE: We recommend using Java2 Standard Edition 5.0 or higher


===================================
4. Supported Star POS Printer Model
===================================
    . SAC10E
    . SAC10EBi
    . TSP650
    . TSP650II
    . FVP10
    . TSP700II
    . TSP800II
    . TSP1000
    . TUP500
    . TUP900
    . TSP100III


======================
5. Supported Interface
======================
    . Serial
    . Parallel
    . Ethernet
    . USB
    . Bluetooth


=================
6. How to Install
=================

6-1.Installing StarIOPort

    unzip "StarJavaPOSEnvironmentTestTool_VXXX.zip" (X is numeric).

    Before use this tool, StarIOPort for Linux should be installed on PC.

    Move to directory "StarJavaPOSEnvironmentTestTool_VXXX directory" - 
    "Linux_x86(x64)" - "StarIOPort_Install_x86(x64)" and run the bash script named "install.sh".
    To run it, login as root (using the "su" or "sudo") and issue this command in the terminal "/bin/bash install.sh" .
    This will copy the library file to the "/usr/lib" directory and header file to the "/usr/include" directory.
    

    e.g)
    [usrname@localhost JavaPOSEnvironmentTestTool_VXXX/Linux_x86(x64)]$ cd StarIOPort_Install_x86(x64)/
    [usrname@localhost StarIOPort_Install_x86]$ sudo /bin/bash install.sh
    Complete! 


6-2.Install JRE(Java Runtime Environment)

    This tool use "java" command.  So need to install and set "JRE" on your PC.

    Please refer to the following URL.

    URL: http://java.com or http://www.oracle.com/technetwork/java/javase/downloads/index.html


6-3.Install command

    This tool use the follwing command for checking port.

    Need to install before starting test tool by login as root.

    If already had installed these command, please skip this step.

      . nmap      (when using for checking TCP/IP port)
      . setserial (when using for checking serial port)
      . hcitool   (when using for checking bluetooth port)
      . rfcomm    (when using for checking bluetooth port)


    e.g) Ubuntu
    [usrname@localhost desktop]$ sudo apt-get install nmap ("setserial" and "bluez"(*) are same as "nmap")
    [sudo] password for usrname: input your password
 
    e.g) OpenSUSE
    [usrname@localhost desktop]$ sudo zypper install nmap ("setserial" and "bluez"(*) are same as "nmap")
    [sudo] password for usrname: input your password
 
    e.g) RedHat, Fedora, CentOS 
    [usrname@localhost desktop]$ su
    [usrname@localhost desktop]$ yum install nmap ("setserial" and "bluez"(*) are same as "nmap")
 
    (*) The "bluez" include "rfcomm" and "hcitool".


=============
7. How to Use
=============

   Move to directory "StarJavaPOSEnvironmentTestTool_VXXX directory" - "Linux_x86(x64)"
   and run the bash script named "CheckStart.sh".
   To run it, login as root(using the "su" or "sudo") and 
   issue this command in the terminal "/bin/bash CheckStart.sh" .

   This will start JavaPOS check test.

    *"CheckStart.sh" check to the following four phase. 
      phase 1: Check for host PC's port
      phase 2: Check for communicating PC and Printer by StarIOPort
      phase 3: Check for communicating PC and Printer by StarIOPort(stario.jar) which based on java. 
      phase 4: Check for communicating PC and Printer by StarJavaPOS

    NOTE: "CheckStart.sh" called "StarIOCheck.sh" and "StarJavaPOSCheck.sh".
          "StarIOCheck.sh" executes phase1 and phase2, And "StarJavaPOSCheck.sh" executes phase3 and phase4.

          If need to see "check tool result sample", input the following command line on "terminal". 
          
          e.g) read the "Check Result Sample" 
          [usrname@localhost desktop]$ cd /home/usrname/Desktop/JavaPOSTestTool/CheckResultSample


    NOTE: The latest version of this tool will upload on a website of "Star Micronics".
      
    NOTE: When using "Bluetooth Port", need to pair the using bluetooth device and host PC 
          before using this tool for checking bluetooth port.



=================================
8. Software Evaluation Environment
=================================
    The evaluation environment is as follows:
        Red Hat Enterprise Linux 6.7 (32bit)
        Red Hat Enterprise Linux 7.2 (64bit)
        openSUSE 13.1      (32bit)
        openSUSE Leap 42.1 (64bit)
        Fedora 20
        Ubuntu 16.04 LTS
        CentOS 6.8   


================
9. Release Notes
================

06/29/2012 first release
Ver 1.0.0

12/14/2012 Add TSP650II and Bluetooth Interface
Ver 1.1.0

11/27/2013 Add CashDrawerTest for SAC10E and SAC10EBi(CashDrawer Interface BOX)
Ver 1.2.0

06/06/2014 Fixed bug : SP700 Parallel interface doe's not work.
Ver 1.2.1  

01/26/2015 Updated StarIO Module.
Ver 1.3.0

06/27/2016 Updated StarIO Module.
Ver 1.4.0