#!/bin/sh
chmod u+x CheckStart.sh
chmod u+x StarIOCheck.sh
chmod u+x StarJavaPOSCheck.sh

rm -f *.tmp

echo "true" >> checkRootAll.tmp

echo "--- StarJavaPOSEnvironmentTestTool version 1.4.0 ---"
echo "*Read the \"readme.txt\" and install some command before starting this check tool."
echo "*This tool has four checking phase."
echo " phase 1: Check for host PC's port"
echo " phase 2: Check for communicating PC and Printer by StarsIO"
echo " phase 3: Check for communicating PC and Printer by StarIO(stario.jar) which based on java." 
echo " phase 4: Check for communicating PC and Printer by StarJavaPOS"
echo ""

echo "Go to next? (y/n)"
read key

if [ "$key" = "y" ];
then
    echo ""
else
    rm -f *.tmp
    exit
fi

./StarIOCheck.sh | tee -a Software/usrLog/CheckStartLog.txt

checkFile=`ls . | grep checkSuccess.tmp`

if [ "$checkFile" != "" ];
then
    checkSuccess=`cat checkSuccess.tmp`
fi

if [ "$checkSuccess" = "true" ];
then
    ./StarJavaPOSCheck.sh | tee -a Software/usrLog/CheckStartLog.txt
fi

exit 0

